<?php
session_start();

// Get the POST data
$data = json_decode(file_get_contents('php://input'), true);
$question_number = $data['question_number'];
$answer = $data['answer'];

// Debug log
error_log("Saving answer for question $question_number: " . print_r($answer, true));

try {
    $db = new SQLite3('answers.db');
    
    // Check if answer exists
    $stmt = $db->prepare('SELECT COUNT(*) as count FROM answers WHERE question_number = :question_number');
    $stmt->bindValue(':question_number', $question_number, SQLITE3_INTEGER);
    $result = $stmt->execute()->fetchArray();
    
    if ($result['count'] > 0) {
        // Update existing answer
        $stmt = $db->prepare('UPDATE answers SET answer = :answer WHERE question_number = :question_number');
    } else {
        // Insert new answer
        $stmt = $db->prepare('INSERT INTO answers (question_number, answer) VALUES (:question_number, :answer)');
    }
    
    $stmt->bindValue(':question_number', $question_number, SQLITE3_INTEGER);
    $stmt->bindValue(':answer', $answer, SQLITE3_TEXT);
    
    $success = $stmt->execute();
    error_log("Save " . ($success ? "successful" : "failed") . " for question $question_number");
    
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    error_log("Error saving answer: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>