<?php
session_start();

// Get questions from the session or file
$json = isset($_SESSION['questionFile']) ? $_SESSION['questionFile'] : file_get_contents('questions.json');
$exam_data = json_decode($json, true);
$questions = $exam_data['questions'];
$exam_name = $exam_data['exam'];


// Connect to the database
try {
    $db = new SQLite3('answers.db');
    
    // Get saved answers from database
    $answers = [];
    $total_points = 0;
    $achieved_points = 0;

    foreach ($questions as $index => $question) {
        $question_number = $index + 1;
        
        // Get answer from database
        $stmt = $db->prepare('SELECT answer FROM answers WHERE question_number = :question_number');
        $stmt->bindValue(':question_number', $question_number, SQLITE3_INTEGER);
        $result = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
        
        if ($result && !empty($result['answer'])) {
            $answers[$question_number] = $result['answer'];
            
            // Add to total points
            $total_points += $question['points'];
            
            // Validate order-type questions automatically
            if ($question['type'] === 'order') {
                $user_order = json_decode($result['answer']);
                if ($user_order === $question['correct_order']) {
                    $achieved_points += $question['points'];
                }
            }
        }
    }

    // Calculate percentage
    $percentage = ($total_points > 0) ? ($achieved_points / $total_points) * 100 : 0;

} catch (Exception $e) {
    die('Database error: ' . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prüfungsbericht</title>
    <link rel="stylesheet" href="report.css">
</head>
<body>
    <div class="header">
        <h1>Prüfungsbericht</h1>
        <h2><?= htmlspecialchars($exam_name) ?></h2>
    </div>

    <button class="slider-nav prev" onclick="changeQuestion(-1)">←</button>
    <button class="slider-nav next" onclick="changeQuestion(1)">→</button>

    <div class="questions-container">
        <?php foreach ($questions as $index => $question): 
            $questionNum = $index + 1;
        ?>
            <div class="question-report" id="question<?= $questionNum ?>">
                <h3><?= $questionNum ?>. <?= $question['title'] ?> (<?= $question['points'] ?> Punkte)</h3>
                <div class="question-text">
                    <?php 
                        $questionText = is_array($question['text']) 
                            ? implode("\n", $question['text']) 
                            : $question['text'];
                        echo nl2br($questionText); 
                    ?>
                </div>
                <div class="answer">
                    <h4>Ihre Antwort:</h4>
                    <?php if (isset($answers[$questionNum])): ?>
                        <?php if ($question['type'] === 'order'): ?>
                            <?php 
                            $user_order = json_decode($answers[$questionNum], true);
                            
                            // Get the original options and sort them by their values (1 to 7)
                            $correct_order = $question['options'];
                            asort($correct_order); // Sort by value while maintaining key associations
                            
                            // Extract just the layer names (keys) in correct order
                            $correct_sequence = array_keys($correct_order);
                            
                            // Extract user's sequence of layer names
                            $user_sequence = is_array($user_order) ? array_keys($user_order) : [];
                            
                            $is_correct = ($user_sequence === $correct_sequence);
                            ?>
                            <p><strong>Your order:</strong> <?= htmlspecialchars(implode(", ", $user_sequence)) ?></p>
                            <p><strong>Correct order:</strong> <?= htmlspecialchars(implode(", ", $correct_sequence)) ?></p>
                            <p class="result <?= $is_correct ? 'correct' : 'incorrect' ?>">
                                Result: <?= $is_correct ? 'Correct!' : 'Incorrect' ?>
                            </p>
                        <?php elseif ($question['type'] === 'multiple_choice'): ?>
                            <?php 
                                $selectedOptions = json_decode($answers[$questionNum], true);
                                foreach ($question['options'] as $key => $val):
                                    $isChecked = is_array($selectedOptions) && 
                                               in_array($key + 1, $selectedOptions);
                            ?>
                                <div class="option <?= $isChecked ? 'selected' : '' ?>">
                                    <?= $isChecked ? '☒' : '☐' ?> <?= htmlspecialchars($val) ?>
                                </div>
                            <?php endforeach; ?>                            
                        <?php else: ?>
                            <div class="text-answer">
                                <?= nl2br(htmlspecialchars($answers[$questionNum])) ?>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="no-answer">Keine Antwort gegeben</p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="navigation">
        <?php for ($i = 1; $i <= count($questions); $i++): ?>
            <div class="nav-dot" onclick="goToQuestion(<?= $i ?>)" data-question="<?= $i ?>"></div>
        <?php endfor; ?>
    </div>

    <div class="footer">
        <button onclick="window.location.href='index.php'">Zurück zur Prüfung</button>
    </div>

    <script>
        let currentQuestion = 1;
        const totalQuestions = <?= count($questions) ?>;
        
        function updateQuestionClasses() {
            document.querySelectorAll('.question-report').forEach((question, index) => {
                const questionNumber = index + 1;
                question.classList.remove('active', 'prev', 'next');
                
                if (questionNumber === currentQuestion) {
                    question.classList.add('active');
                } else if (questionNumber === currentQuestion - 1) {
                    question.classList.add('prev');
                } else if (questionNumber === currentQuestion + 1) {
                    question.classList.add('next');
                }
            });

            // Update navigation dots
            document.querySelectorAll('.nav-dot').forEach((dot, index) => {
                dot.classList.toggle('active', index + 1 === currentQuestion);
            });

            // Update navigation buttons
            document.querySelector('.slider-nav.prev').style.visibility = 
                currentQuestion === 1 ? 'hidden' : 'visible';
            document.querySelector('.slider-nav.next').style.visibility = 
                currentQuestion === totalQuestions ? 'hidden' : 'visible';
        }

        function changeQuestion(direction) {
            const newQuestion = currentQuestion + direction;
            if (newQuestion >= 1 && newQuestion <= totalQuestions) {
                currentQuestion = newQuestion;
                updateQuestionClasses();
            }
        }

        function goToQuestion(number) {
            if (number >= 1 && number <= totalQuestions) {
                currentQuestion = number;
                updateQuestionClasses();
            }
        }

        // Initialize the first question
        document.addEventListener('DOMContentLoaded', () => {
            updateQuestionClasses();
        });

        // Add keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') {
                changeQuestion(-1);
            } else if (e.key === 'ArrowRight') {
                changeQuestion(1);
            }
        });

        // Add mouse wheel (jog dial) navigation
        document.addEventListener('wheel', (e) => {
            // Prevent default scrolling
            e.preventDefault();
            
            // Determine scroll direction
            if (e.deltaY > 0) {
                changeQuestion(1); // Scroll down/right
            } else if (e.deltaY < 0) {
                changeQuestion(-1); // Scroll up/left
            }
            }, { passive: false });
    </script>
</body>
</html>