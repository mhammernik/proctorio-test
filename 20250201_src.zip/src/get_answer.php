<?php
session_start();

header('Content-Type: application/json');

try {
    if (!isset($_SESSION['current_exam_table'])) {
        throw new Exception('No active exam session');
    }
    
    $table_name = $_SESSION['current_exam_table'];
    $question_number = isset($_GET['q']) ? (int)$_GET['q'] : 0;
    
    $db = new SQLite3('answers.db');
    $stmt = $db->prepare("SELECT answer FROM $table_name WHERE question_number = :question_number");
    $stmt->bindValue(':question_number', $question_number, SQLITE3_INTEGER);
    
    $result = $stmt->execute();
    $row = $result->fetchArray(SQLITE3_ASSOC);
    
    echo json_encode([
        'success' => true,
        'answer' => $row ? $row['answer'] : null
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>