<?php
session_start();

header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($_SESSION['current_exam_table'])) {
        throw new Exception('No active exam session');
    }
    
    $table_name = $_SESSION['current_exam_table'];
    $db = new SQLite3('answers.db');
    
    // Check if answer already exists
    $stmt = $db->prepare("SELECT id FROM $table_name WHERE question_number = :question_number");
    $stmt->bindValue(':question_number', $data['question_number'], SQLITE3_INTEGER);
    $result = $stmt->execute();
    $existing = $result->fetchArray();
    
    if ($existing) {
        // Update existing answer
        $stmt = $db->prepare("UPDATE $table_name SET answer = :answer, timestamp = CURRENT_TIMESTAMP WHERE question_number = :question_number");
    } else {
        // Insert new answer
        $stmt = $db->prepare("INSERT INTO $table_name (question_number, answer) VALUES (:question_number, :answer)");
    }
    
    $stmt->bindValue(':question_number', $data['question_number'], SQLITE3_INTEGER);
    $stmt->bindValue(':answer', $data['answer'], SQLITE3_TEXT);
    
    $stmt->execute();
    
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>