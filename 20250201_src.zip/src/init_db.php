<?php
session_start();

header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    $exam_name = $data['exam_name'];
    
    // Sanitize exam name for table name (remove special characters, spaces)
    $table_name = 'answers_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $exam_name);
    
    $db = new SQLite3('answers.db');
    
    // Create answers table for this specific exam if it doesn't exist
    $query = "CREATE TABLE IF NOT EXISTS $table_name (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question_number INTEGER NOT NULL,
        answer TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )";
    
    $db->exec($query);
    
    // Store the current table name in the session
    $_SESSION['current_exam_table'] = $table_name;
    
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>