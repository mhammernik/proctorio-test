<?php
session_start();

if (!isset($_SESSION['current_exam_table'])) {
    header('Location: index.php');
    exit;
}

// Get exam data from session
$json = isset($_SESSION['questionFile']) ? $_SESSION['questionFile'] : file_get_contents('questions.json');
$exam_data = json_decode($json, true);
$questions = $exam_data['questions'];
$exam_name = $exam_data['exam'];

// Initialize answers array
$answers = [];

// Connect to database and get answers
try {
    $table_name = $_SESSION['current_exam_table'];
    $db = new SQLite3('answers.db');
    
    // Verify table exists
    $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='$table_name'");
    if (!$tableCheck->fetchArray()) {
        throw new Exception("Table $table_name does not exist");
    }
    
    // Get all answers for this exam using direct table name
    $query = "SELECT question_number, answer FROM $table_name ORDER BY question_number";
    $result = $db->query($query);
    
    if ($result) {
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $answers[$row['question_number']] = $row['answer'];
        }
    }
} catch (Exception $e) {
    error_log('Database Error: ' . $e->getMessage());
    // Initialize empty answers array if there's an error
    $answers = [];
}

// Calculate exam statistics
$total_questions = count($questions);
$answered_questions = 0;
$total_points = 0;
$possible_points = 0;

foreach ($questions as $index => $question) {
    $question_number = $index + 1;
    $possible_points += $question['points'];
    
    if (isset($answers[$question_number]) && !empty($answers[$question_number])) {
        $answered_questions++;
        // For multiple choice, check if any option was selected
        if ($question['type'] === 'multiple_choice') {
            $selected_options = json_decode($answers[$question_number], true);
            if (!empty($selected_options)) {
                $total_points += $question['points'];
            }
        } else {
            // For text answers, if there's any content, count the points
            if (trim($answers[$question_number]) !== '') {
                $total_points += $question['points'];
            }
        }
    }
}

$completion_percentage = ($answered_questions / $total_questions) * 100;
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prüfungsbericht</title>
    <link rel="stylesheet" href="report.css">
</head>
<body>
    <div class="header">
        <h1>Prüfungsbericht</h1>
        <h2><?= htmlspecialchars($exam_name) ?></h2>
    </div>

    <button class="slider-nav prev" onclick="changeQuestion(-1)">←</button>
    <button class="slider-nav next" onclick="changeQuestion(1)">→</button>

    <div class="questions-container">
        <?php foreach ($questions as $index => $question): 
            $questionNum = $index + 1;
        ?>
            <div class="question-report" id="question<?= $questionNum ?>">
                <h3><?= $questionNum ?>. <?= $question['title'] ?> (<?= $question['points'] ?> Punkte)</h3>
                <div class="question-text">
                    <?php 
                        $questionText = is_array($question['text']) 
                            ? implode("\n", $question['text']) 
                            : $question['text'];
                        echo nl2br($questionText); 
                    ?>
                </div>
                <div class="answer">
                    <h4>Ihre Antwort:</h4>
                    <?php if (isset($answers[$questionNum])): ?>
                        <?php if ($question['type'] === 'multiple_choice'): ?>
                            <?php 
                                $selectedOptions = json_decode($answers[$questionNum], true);
                                foreach ($question['options'] as $key => $val):
                                    $isChecked = is_array($selectedOptions) && 
                                               in_array($key + 1, $selectedOptions);
                            ?>
                                <div class="option <?= $isChecked ? 'selected' : '' ?>">
                                    <?= $isChecked ? '☒' : '☐' ?> <?= htmlspecialchars($val) ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-answer">
                                <?= nl2br(htmlspecialchars($answers[$questionNum])) ?>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="no-answer">Keine Antwort gegeben</p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="navigation">
        <?php for ($i = 1; $i <= count($questions); $i++): ?>
            <div class="nav-dot" onclick="goToQuestion(<?= $i ?>)" data-question="<?= $i ?>"></div>
        <?php endfor; ?>
    </div>

    <div class="footer">
        <button onclick="window.location.href='index.php'">Zurück zur Prüfung</button>
    </div>

    <script>
        let currentQuestion = 1;
        const totalQuestions = <?= count($questions) ?>;
        
        function updateQuestionClasses() {
            document.querySelectorAll('.question-report').forEach((question, index) => {
                const questionNumber = index + 1;
                question.classList.remove('active', 'prev', 'next');
                
                if (questionNumber === currentQuestion) {
                    question.classList.add('active');
                } else if (questionNumber === currentQuestion - 1) {
                    question.classList.add('prev');
                } else if (questionNumber === currentQuestion + 1) {
                    question.classList.add('next');
                }
            });

            // Update navigation dots
            document.querySelectorAll('.nav-dot').forEach((dot, index) => {
                dot.classList.toggle('active', index + 1 === currentQuestion);
            });

            // Update navigation buttons
            document.querySelector('.slider-nav.prev').style.visibility = 
                currentQuestion === 1 ? 'hidden' : 'visible';
            document.querySelector('.slider-nav.next').style.visibility = 
                currentQuestion === totalQuestions ? 'hidden' : 'visible';
        }

        function changeQuestion(direction) {
            const newQuestion = currentQuestion + direction;
            if (newQuestion >= 1 && newQuestion <= totalQuestions) {
                currentQuestion = newQuestion;
                updateQuestionClasses();
            }
        }

        function goToQuestion(number) {
            if (number >= 1 && number <= totalQuestions) {
                currentQuestion = number;
                updateQuestionClasses();
            }
        }

        // Initialize the first question
        document.addEventListener('DOMContentLoaded', () => {
            updateQuestionClasses();
        });

        // Add keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') {
                changeQuestion(-1);
            } else if (e.key === 'ArrowRight') {
                changeQuestion(1);
            }
        });

        // Add mouse wheel (jog dial) navigation
        document.addEventListener('wheel', (e) => {
            // Prevent default scrolling
            e.preventDefault();
            
            // Determine scroll direction
            if (e.deltaY > 0) {
                changeQuestion(1); // Scroll down/right
            } else if (e.deltaY < 0) {
                changeQuestion(-1); // Scroll up/left
            }
            }, { passive: false });
    </script>
</body>
</html>