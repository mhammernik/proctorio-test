<?php
    // Start the session at the very beginning
    session_start();
    
    // Get question number from URL parameter (default to 1 if not set)
    $question_number = isset($_GET['q']) ? (int)$_GET['q'] : 1;
    
    // Initialize timer if not set
    if (!isset($_SESSION['timer_start'])) {
        $_SESSION['timer_start'] = time();
    }
    
    // Get questions from uploaded file or default to questions.json
    $json = isset($_SESSION['questionFile']) ? $_SESSION['questionFile'] : file_get_contents('questions.json');
    $questions = json_decode($json, true)['questions'];
    
    // Arrays are 0-based, but we want questions to start at 1
    $question_index = $question_number - 1;
    
    // Check if question exists
    if (!isset($questions[$question_index])) {
        header('Location: index.php?q=1');
        exit;
    }
    
    $current_question = $questions[$question_index];
    $total_questions = count($questions);

    
    
    $exam_title = json_decode($json, true)['exam'];
    $exam_subtitle = $current_question['title'];
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prüfungsraum: <?php echo json_decode($json, true)['exam']; ?></title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="iCheck.css">
</head>
<body>
    <div class="container">
        <!--<img class="header-logo" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+DQo8IURPQ1RZUEUgc3ZnIFBVQkxJQyAiLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4iICJodHRwOi8vd3d3LnczLm9yZy9HcmFwaGljcy9TVkcvMS4xL0RURC9zdmcxMS5kdGQiPg0KPHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB2aWV3Qm94PSIwIDAgMTA2IDEwNiIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4bWw6c3BhY2U9InByZXNlcnZlIiB4bWxuczpzZXJpZj0iaHR0cDovL3d3dy5zZXJpZi5jb20vIiBzdHlsZT0iZmlsbC1ydWxlOmV2ZW5vZGQ7Y2xpcC1ydWxlOmV2ZW5vZGQ7c3Ryb2tlLWxpbmVqb2luOnJvdW5kO3N0cm9rZS1taXRlcmxpbWl0OjI7Ij48cGF0aCBkPSJNMTA1LjU3LDBsLTEwNS41NywwbDAsMTA1LjU3bDEwNS41NywtMGwtMCwtMTA1LjU3IiBzdHlsZT0iZmlsbDojMDJjNmIyO2ZpbGwtcnVsZTpub256ZXJvOyIvPjxwYXRoIGQ9Ik04NC43NzcsMTkuMTc3bC01LjEzNSwyMi4ybC01LjA4NSwtMjIuMmwtNS45OTEsMGwtMy40MjMsNTEuM2w3LjU1MywwbDEuMTA4LC0yMi43bDUuODM5LDIyLjdsNS44NCwtMjIuN2wxLjEwOCwyMi43bDcuNTUyLDBsLTMuNDIzLC01MS4zbC01Ljk0MywwbS02NiwxOC44NzlsNS44ODksMGwwLDEzLjg0NGwtNS44ODksMGwtMCwxOC42MjdsLTcuMzUxLDBsMCwtNTEuMzVsMTUuNTA2LDBsMS4yNTksMTMuNDkybC05LjQxNSwwbDAsNS4zODdtMjcuMTg2LC0yMC41NGMtMi4wMTksMC4xMTYgLTMuOTUzLDAuODU0IC01LjUzNiwyLjExNGMtMS44MzksMS42NTUgLTMuMzU4LDMuNjM1IC00LjQ4MSw1Ljg0MWMtMi43ODgsNi4wMDcgLTQuMjE1LDEyLjU1NyAtNC4xNzgsMTkuMTgxYzAuMDM4LDYuNjIzIDAsMTEuMTc2IDQuMTc4LDE5LjEzMWMxLjE2MiwyLjE2NCAyLjY3Nyw0LjEyMSA0LjQ4Miw1Ljc4OGMxLjU5MSwxLjI1NCAzLjUxOCwyLjAwNyA1LjUzNywyLjE2NWMyLjAzLC0wLjExMiAzLjk3MSwtMC44NzEgNS41MzksLTIuMTY1YzEuODU2LC0xLjYzMiAzLjM5MiwtMy41OTUgNC41MywtNS43ODljMi43ODUsLTUuOTkxIDQuMjEyLC0xMi41MjQgNC4xNzksLTE5LjEzMWMtMC4wMzQsLTYuNjA2IC0wLC0xMS4yMjcgLTQuMTc4LC0xOS4xODFjLTEuMTYzLC0yLjE5MyAtMi42OTYsLTQuMTY5IC00LjUzMiwtNS44NGMtMS42MDEsLTEuMjI4IC0zLjUyNywtMS45NjMgLTUuNTQsLTIuMTEzWm0wLDE0LjI0NmMwLDAgMi44MTksMCA0Ljc4MywzLjc3NmMxLjMxMiwyLjg1OCAxLjk4Myw1Ljk2OCAxLjk2NCw5LjExMmMtMC4wMiwzLjE0NSAtMCw1LjMzNiAtMS45NjQsOS4xMTJjMCwwIC0xLjk2MywzLjcyNSAtNC43ODIsMy43MjVjLTAsMCAtMi43NjksMCAtNC43ODMsLTMuNzI1Yy0xLjMxMiwtMi44NTcgLTEuOTgzLC01Ljk2NyAtMS45NjMsLTkuMTEyYzAuMDE5LC0zLjE0NCAtMCwtNS4zMzYgMS45NjMsLTkuMTEyYy0wLjAwMSwwIDIuMDEzLC0zLjc3NiA0Ljc4MiwtMy43NzZaIiBzdHlsZT0iZmlsbDojZmZmO2ZpbGwtcnVsZTpub256ZXJvOyIvPjxwYXRoIGQ9Ik04Mi41NjIsNzUuNDYybC0wLjAwMSwxMi4zODVsMS44NjYsMGwtMCwtMTIuMzg1bC0xLjg2MywwbS00LjI3OSwzLjgyNmwtMCwzLjk3N2MtMC4wMDIsMC43MDggLTAuMTM4LDEuNDA4IC0wLjQsMi4wNjVjLTAuMzc2LDAuNjc3IC0xLjA4OSwxLjEwMSAtMS44NjMsMS4xMDhjLTAuNDgsLTAuMDMgLTAuOTIyLC0wLjI3IC0xLjIwOCwtMC42NTVjLTAuMjgsLTAuNjUxIC0wLjQwMSwtMS4zNTggLTAuMzUyLC0yLjA2NWwtMCwtNC40M2wtMS44NjMsMGwtMCw1LjAzNGMtMC4wMDQsMC45ODIgMC4yNzUsMS45NDMgMC44MDUsMi43NjljMC42MzcsMC42NDEgMS41MTMsMC45ODggMi40MTcsMC45NTZsMS40NTksLTAuM2wxLjA1OCwtMC44MDVsLTAuMDAxLDAuOTA2bDEuODY0LDBsLTAuMDAxLC04LjU1OGwtMS45MTMsMG0tMTUuNTEsLTMuODI4bC0wLDEyLjM4NWwxLjkxMywwbC0wLC0zLjk3N2MwLjAwMywtMC42OSAwLjEzOCwtMS4zNzQgMC40LC0yLjAxNGMwLjM2MiwtMC42OTUgMS4wNzgsLTEuMTQgMS44NjIsLTEuMTU3YzAuNDksMC4wMzIgMC45MzcsMC4yOTEgMS4yMDksMC42OTljMC4yNzYsMC42MzQgMC4zOTcsMS4zMjUgMC4zNTIsMi4wMTRsLTAuMDAxLDQuNDNsMS44NjQsMGwtMC4wMDEsLTUuMDM0YzAuMDA0LC0wLjk4MSAtMC4yNzUsLTEuOTQyIC0wLjgwNSwtMi43NjljLTAuNjQ1LC0wLjYyNyAtMS41MTUsLTAuOTcyIC0yLjQxNSwtMC45NTdjLTAuOTI5LDAuMDE5IC0xLjgxNCwwLjM5OCAtMi40NjcsMS4wNTdsLTAsLTQuNjc3bC0xLjkxMSwwbS0xLjUxLDEwLjM3MWwtMC4yNTIsMC4xNTJsLTEuNTEsMC40NTNjLTAuNzUyLC0wLjAxNyAtMS40NjMsLTAuMzQ2IC0xLjk2NCwtMC45MDZjLTAuNzU1LC0xLjIwMyAtMC43MzUsLTIuNzQ0IDAuMDUxLC0zLjkyN2MwLjQ0OSwtMC41NDMgMS4xMDcsLTAuODcyIDEuODEyLC0wLjkwNmMwLjUzNywwLjAxOSAxLjA2NywwLjEzOSAxLjU2MSwwLjM1M2wwLjI1MiwwLjFsMC4xNTEsLTEuNjYxbC0wLjEsLTAuMDVsLTEuOTE0LC0wLjM1MmMtMS4xNTgsMC4wMjcgLTIuMjY3LDAuNDc1IC0zLjEyLDEuMjU5Yy0wLjc3MywwLjg5NiAtMS4yMDEsMi4wMzggLTEuMjA5LDMuMjIyYzAuMDI4LDEuMTY0IDAuNDU1LDIuMjg0IDEuMjA5LDMuMTcyYzAuODQyLDAuODA3IDEuOTU0LDEuMjc0IDMuMTIsMS4zMDhsMS45NjQsLTAuMzUybDAuMSwtMC4wNDlsLTAuMTUxLC0xLjgxMm0tNy42LC00LjU4MWwwLjIsLTEuNzYybC0wLjE1MiwtMC4wNWwtMS45NjMsLTAuMzUyYy0wLjgsMC4wMDUgLTEuNTc3LDAuMjcgLTIuMjE1LDAuNzU1Yy0wLjUyMSwwLjUxOSAtMC44MTEsMS4yMjcgLTAuODA1LDEuOTYzYzAuMDI2LDAuNTkgMC4yNzcsMS4xNDkgMC43LDEuNTYxbDEuNDEsMC45MDZsMS4wMDgsMC41YzAuMjIyLDAuMTY5IDAuMzY3LDAuNDIyIDAuMzk5LDAuN2MtMC4wMTYsMC4zNzcgLTAuMjUxLDAuNzExIC0wLjYsMC44NTZsLTAuNzU1LDAuMWwtMC44MDUsLTAuMWwtMC45NTcsLTAuNDUzbC0wLjMsLTAuMTUxbC0wLjEsMS43NjJsMC4xLDAuMDVjMC43MzksMC4zNDggMS41NSwwLjUxOSAyLjM2NiwwLjVjMC43MzcsLTAuMDE2IDEuNDU0LC0wLjI0MyAyLjA2NSwtMC42NTRjMC41OTcsLTAuNTIxIDAuOTQ1LC0xLjI3MiAwLjk1NiwtMi4wNjRjLTAuMDEzLC0wLjYzOCAtMC4yNjMsLTEuMjQ4IC0wLjcsLTEuNzEyYy0wLjQ0NSwtMC4zNTEgLTAuOTM2LC0wLjYzOSAtMS40NiwtMC44NTZsLTEuMDA3LC0wLjU1NWMtMC4yMDIsLTAuMTc5IC0wLjMyOCwtMC40MyAtMC4zNTIsLTAuN2MwLjAxNiwtMC4yNTcgMC4xNjksLTAuNDg2IDAuNCwtMC41OTlsMC44NTYsLTAuMjAxbDAuNywwLjFsMC43NTUsMC4zbDAuMjUyLDAuMTUxbS0xNCwtNS43OWwwLDEyLjM4NWwxLjg2MywwbDAsLTMuOTc3YzAuMDA0LC0wLjY5IDAuMTM5LC0xLjM3NCAwLjQsLTIuMDEzYzAuMzYzLC0wLjY5NiAxLjA3OSwtMS4xNDEgMS44NjMsLTEuMTU4YzAuNDksMC4wMzIgMC45MzcsMC4yOTEgMS4yMDgsMC43YzAuMjc3LDAuNjMzIDAuMzk4LDEuMzI0IDAuMzUyLDIuMDE0bDAsNC40M2wxLjg2MywtMGwwLC01LjAzNWMwLjAwNCwtMC45ODEgLTAuMjc1LC0xLjk0MiAtMC44MDUsLTIuNzY4Yy0wLjYzNywtMC42NDIgLTEuNTEzLC0wLjk4OSAtMi40MTcsLTAuOTU4Yy0wLjkyNiwwLjAyNyAtMS44MDgsMC40MDUgLTIuNDY3LDEuMDU4bDAsLTQuNjc3bC0xLjg2MywwbS0xLjgxMiw1LjU4OGwwLjIsMC4xbDAuMiwtMS42NjFsLTAuMTUxLC0wLjA1Yy0wLjYxLC0wLjIzNSAtMS4yNTgsLTAuMzU1IC0xLjkxMywtMC4zNTJjLTEuMTU4LDAuMDI4IC0yLjI2NywwLjQ3NiAtMy4xMjEsMS4yNTljLTEuNjIyLDEuODE4IC0xLjYsNC42MDMgMC4wNSw2LjM5NGMwLjgxOSwwLjgxMyAxLjkxOSwxLjI4MiAzLjA3MSwxLjMwOWwxLjk2MywtMC4zNTJsMC4xNTEsLTAuMDVsLTAuMTUxLC0xLjgxMmwtMC4yNTIsMC4xNTFsLTEuNTEsMC40NTNjLTAuNzUzLC0wLjAwOCAtMS40NjcsLTAuMzM4IC0xLjk2MywtMC45MDZjLTAuMzg5LC0wLjU4IC0wLjU5OCwtMS4yNjMgLTAuNiwtMS45NjJjMC4wMTIsLTAuNjk4IDAuMjIsLTEuMzc5IDAuNiwtMS45NjRjMC40NjUsLTAuNTUyIDEuMTQzLC0wLjg4MSAxLjg2MywtMC45MDZsMS41NjEsMC4zNTRtLTExLjMyNywtMS45NjNjLTEuMTU4LDAuMDI3IC0yLjI2NywwLjQ3NSAtMy4xMjEsMS4yNTljLTEuNjIyLDEuODE3IC0xLjYsNC42MDIgMC4wNSw2LjM5M2MwLjgxOSwwLjgxMyAxLjkxOSwxLjI4MiAzLjA3MSwxLjMxYzEuMTY2LC0wLjAzOSAyLjI3NywtMC41MDUgMy4xMjEsLTEuMzA5YzAuNzY2LC0wLjg4MSAxLjE5NCwtMi4wMDYgMS4yMDgsLTMuMTcyYy0wLjAyMSwtMS4xNzIgLTAuNDI4LC0yLjMwNSAtMS4xNTgsLTMuMjIyYy0wLjg2NiwtMC43OTEgLTEuOTkxLC0xLjI0IC0zLjE2NCwtMS4yNjRsLTAuMDA3LDAuMDA1Wm0wLDEuNjExYzAuNjkzLDAuMDI2IDEuMzM4LDAuMzU4IDEuNzYyLDAuOTA2YzAuMzc5LDAuNTg1IDAuNTg3LDEuMjY1IDAuNiwxLjk2M2MtMC4wMSwwLjY5MSAtMC4yMDEsMS4zNjggLTAuNTU0LDEuOTYzYy0wLjQzOCwwLjU1NiAtMS4xMDMsMC44ODggLTEuODEyLDAuOTA2Yy0wLjY5MiwtMC4wMjcgLTEuMzM3LC0wLjM1OSAtMS43NjIsLTAuOTA2Yy0wLjM4OSwtMC41ODEgLTAuNTk4LC0xLjI2NCAtMC42LC0xLjk2M2MwLjAxOCwtMC42OTcgMC4yMjYsLTEuMzc2IDAuNiwtMS45NjNjMC40MzgsLTAuNTM4IDEuMDgyLC0wLjg2OCAxLjc3MywtMC45MWwtMC4wMDcsMC4wMDRabS04LjE1NiwtNC4zOGwwLDQuNjMybC00Ljk4NCwtMGwwLC00LjYzMmwtMS45NTMsLTBsMCwxMS41MjlsMS45NjMsLTBsMCwtNS4wOWw0Ljk4NSwwbC0wLDUuMDg1bDEuOTYyLDBsMCwtMTEuNTI5bC0xLjk2MiwwbTcxLjk0MSwyLjc2OWMtMS4wOSwwLjAyNSAtMi4xMzIsMC40NTYgLTIuOTIsMS4yMDljLTAuNzE5LDAuODgxIC0xLjExLDEuOTg0IC0xLjEwOCwzLjEyMWMwLjAwMywxLjIzNiAwLjQxLDIuNDM4IDEuMTU4LDMuNDIyYzAuODcyLDAuODExIDIuMDMxLDEuMjQ2IDMuMjIyLDEuMjA5bDIuNDY2LC0wLjQ1M2wwLjMwMSwtMC4xNTFsLTAsLTIuMDE0bC0wLjMsMC4yNTJsLTAuOTU3LDAuNWwtMS40MTEsMC4yNTJjLTAuNjAzLC0wLjAxOCAtMS4xODUsLTAuMjI5IC0xLjY2LC0wLjZjLTAuNDc4LC0wLjQ1MyAtMC43ODEsLTEuMDU5IC0wLjg1NywtMS43MTJsNS44NCwtMGwwLC0wLjJjMCwtMCAwLjAwMSwtNC44MzUgLTMuNzc1LC00LjgzNVptLTAuMDQ5LDEuNjEyYzAuNTE0LDAuMDExIDEuMDAzLDAuMjI3IDEuMzU5LDAuNTk5YzAuMjk4LDAuMzc1IDAuNDcyLDAuODMyIDAuNSwxLjMwOWwtMy44MjcsMGMwLjA2OSwtMC40MjkgMC4yMjMsLTAuODM5IDAuNDUzLC0xLjIwOGMwLjM4MiwtMC40MzggMC45MzMsLTAuNjkzIDEuNTE1LC0wLjcwMVoiIHN0eWxlPSJmaWxsOiNmZmY7ZmlsbC1ydWxlOm5vbnplcm87Ii8+PC9zdmc+" alt="Logo">-->
        
        <input type="file" id="questionFile" accept=".json" onchange="loadQuestions(this)" 
               nwdirectory nwworkingdir="/" hidden/>
        <label class="jsonInput" for="questionFile"> ◥ </label>
        <h1>Prüfungsraum: <?php echo json_decode($json, true)['exam']; ?></h1>
    </div>
    <script>
    function loadQuestions(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                // Validate JSON format
                const jsonContent = JSON.parse(e.target.result);
                
                // First initialize the database for this exam
                fetch('init_db.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        exam_name: jsonContent.exam
                    })
                })
                .then(response => response.json())
                .then(initData => {
                    if (initData.success) {
                        // After successful initialization, save the questions
                        return fetch('save_questions.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                questionFile: e.target.result
                            })
                        });
                    } else {
                        throw new Error('Database initialization failed');
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = 'index.php?q=1';
                    } else {
                        alert('Error saving questions');
                    }
                });
            } catch (e) {
                alert('Invalid JSON file format');
            }
        };
        reader.readAsText(input.files[0]);
    }
}
</script>    
    <div class="timer">Zeit verbleibend: <span id="countdown">01:30:00</span></div>
    <script>
        // Get start time from PHP session
        const startTime = <?php echo $_SESSION['timer_start']; ?>;
        const totalTime = 90 * 60; // 90 minutes in seconds
        
        function updateTimer() {
            const currentTime = Math.floor(Date.now() / 1000);
            const elapsedTime = currentTime - startTime;
            const timeLeft = Math.max(0, totalTime - elapsedTime);
            
            const hours = Math.floor(timeLeft / 3600);
            const minutes = Math.floor((timeLeft % 3600) / 60);
            const seconds = timeLeft % 60;
            
            // Format time as HH:MM:SS
            const timeString = `${hours.toString().padStart(2,'0')}:${minutes.toString().padStart(2,'0')}:${seconds.toString().padStart(2,'0')}`;
            
            document.getElementById('countdown').textContent = timeString;
            
            if (timeLeft > 0) {
                setTimeout(updateTimer, 1000);
            } else {
                // Show reset popup when timer ends
                const reset = confirm('Time is up! Would you like to reset the timer?');
                if (reset) {
                    // Reset session timer and reload page
                    fetch('reset_timer.php')
                        .then(() => window.location.reload());
                }
            }
        }
        
        // Start the countdown
        updateTimer();
    </script>
    <div class="content">
    <div class="question-header">
            <h2><?= $question_number ?>. Aufgabe (<?= $current_question['points'] ?> Punkte)</h2>
            <span><?=$exam_title?></span>
            <span><?=$exam_subtitle?></span>
        </div>
        <div class="pagination">
            <?php for ($i = 1; $i <= $total_questions; $i++): ?>
                <a href="?q=<?= $i ?>"><div <?= $i === $question_number ? 'class="active"' : '' ?>><?= $i ?></div></a>
            <?php endfor; ?>
        </div>
        <p>
            <?php 
                // Check if text is an array and join with line breaks if it is
                $questionText = is_array($current_question['text']) 
                    ? implode("\n", $current_question['text']) 
                    : $current_question['text'];
                echo nl2br($questionText); 
            ?>
        </p>
        
        <?php if ($current_question['type'] === 'multiple_choice'): ?>
    <div>
        <?php foreach ($current_question['options'] as $key => $val): ?>
            <label class="c-custom-checkbox">
                <input name="q<?=$question_number?>_option<?=$key+1?>"
                       value="<?=$key+1?>" 
                       type="checkbox" 
                       onchange="saveAnswer(<?=$question_number?>, getMultipleChoiceAnswers(<?=$question_number?>))" />
                <svg width="32" height="32" viewBox="-4 -4 39 39" aria-hidden="true" focusable="false">
                    <rect class="checkbox__background" width="35" height="35" x="-2" y="-2" stroke="currentColor" fill="none" stroke-width="3" rx="6" ry="6"></rect>
                    <polyline class="checkbox__checkmark" points="4,14 12,23 28,5" stroke="transparent" stroke-width="4" fill="none"></polyline>
                </svg>
                <span class="checkbox-label"><?= htmlspecialchars($val) ?></span>
            </label>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="textarea-container">
        <textarea id="answer<?=$question_number?>" 
                  placeholder="Antwort:" 
                  oninput="saveAnswer(<?=$question_number?>, this.value)"></textarea>
        <?php if (isset($current_question['hint'])): ?>
            <button class="hint-button" onclick="toggleHint()">+ Hinweis</button>
            <div id="hint-text" class="hint-text" style="display: none;">
                <?php echo nl2br(htmlspecialchars($current_question['hint'])); ?>
            </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

        <div class="buttons">
            <?php if ($question_number > 1): ?>
                <button class="back" onclick="window.location.href='?q=<?= $question_number - 1 ?>'">Zurück</button>
            <?php endif; ?>
            <button class="submit" onclick="submitExam()">Zur Abgabe</button>
            <?php if ($question_number < $total_questions): ?>
                <button class="next" onclick="window.location.href='?q=<?= $question_number + 1 ?>'">Weiter</button>
            <?php endif; ?>
        </div>

        <script>
        let saveTimeout;

        // Load saved answers when page loads
        document.addEventListener('DOMContentLoaded', function() {
            fetch(`get_answer.php?q=${<?=$question_number?>}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.answer) {
                        if ('<?=$current_question['type']?>' === 'multiple_choice') {
                            try {
                                // Parse the stored JSON array of selected options
                                const selectedOptions = JSON.parse(data.answer);
                                // Check the corresponding checkboxes
                                selectedOptions.forEach(optionNum => {
                                    const checkbox = document.querySelector(`input[name="q${<?=$question_number?>}_option${optionNum}"]`);
                                    if (checkbox) {
                                        checkbox.checked = true;
                                    }
                                });
                            } catch (e) {
                                console.error('Error parsing multiple choice answer:', e);
                            }
                        } else {
                            // Handle text answers as before
                            const textarea = document.getElementById(`answer${<?=$question_number?>}`);
                            if (textarea) textarea.value = data.answer;
                        }
                    }
                })
                .catch(error => console.error('Error loading answer:', error));
        });

        // Update the getMultipleChoiceAnswers function to ensure consistent format
        function getMultipleChoiceAnswers(questionNumber) {
            const answers = [];
            const checkboxes = document.querySelectorAll(`input[name^="q${questionNumber}_option"]`);
            checkboxes.forEach((checkbox, index) => {
                if (checkbox.checked) {
                    answers.push(index + 1); // Add 1 because arrays are 0-based
                }
            });
            return JSON.stringify(answers); // Convert to JSON string for storage
        }

            function saveAnswer(questionNumber, answer) {
                // Clear any existing timeout
                clearTimeout(saveTimeout);
                
                // Set a new timeout to save after 500ms of no typing
                saveTimeout = setTimeout(() => {
                    fetch('save_answer.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            question_number: questionNumber,
                            answer: answer
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (!data.success) {
                            console.error('Error saving answer:', data.error);
                        }
                    });
                }, 500);
            }
        

        function submitExam() {
            if (confirm('Möchten Sie die Prüfung wirklich abgeben?')) {
                window.location.href = 'report.php';
            }
        }

        // Load saved answers when page loads
        document.addEventListener('DOMContentLoaded', function() {
            fetch(`get_answer.php?q=${<?=$question_number?>}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.answer) {
                        if (data.type === 'multiple_choice') {
                            const answers = JSON.parse(data.answer);
                            answers.forEach(answer => {
                                const checkbox = document.querySelector(`input[name="q${<?=$question_number?>}_option${answer}"]`);
                                if (checkbox) checkbox.checked = true;
                            });
                        } else {
                            const textarea = document.getElementById(`answer${<?=$question_number?>}`);
                            if (textarea) textarea.value = data.answer;
                        }
                    }
                });
        });

        function toggleHint() {
            const hintText = document.getElementById('hint-text');
            const hintButton = document.querySelector('.hint-button');
            
            if (hintText.style.display === 'none') {
                hintText.style.display = 'block';
                hintButton.textContent = '- Hinweis';
            } else {
                hintText.style.display = 'none';
                hintButton.textContent = '+ Hinweis';
            }
        }
        </script>
    </div>
</body>
</html>